

/**
 *
 * @author tapir
 */
public class Player {
    
    static int x,y;
    public Player(int cx, int cy){
        x = cx;
        y = cy;
    }
    
}
