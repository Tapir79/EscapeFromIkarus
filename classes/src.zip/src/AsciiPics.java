

/**
 *
 * @author tapir
 */
public class AsciiPics {
    
    
    public static void theGirl(){

System.out.println("     @@@@B@@@BBBMJ.                   vB@BOB@M@B@        ");
System.out.println("    @@@B@B@B@BOv7uNOMu:             rPB0i@@@@F@B@B@      ");
System.out.println("    B@BM@@@@B@@@ZNZMB@@@Mv       :k@@@NZEOB@@@r@B@B@     ");
System.out.println("   @@@Z.@B@MqB@B@BMB@B@@@B0     rB@M@B@L@B@J@@@i@B@B@B   ");
System.out.println(" @B@B@@jq@BN v@B@7uSi .B@Bj   .:; ,Xv:Mj@@@@@@@@B@B@@@B ");
System.out.println(" B@B@@@EqB@M:  i1OPv.    BE,      ..:7.@@@@@@@@q@B@B@B");
System.out.println("B@@@B@BBq1B@F          . 8G,           .r@@@@@@@@B@B@B@@");
System.out.println("@B@@@@@B@B@B@BNr.     .. BX.             B@@@@@@@@vB@B@B@");
System.out.println("B@B@B@B@B@@@BO0Ur.   ...EB@:  .         :@B@@@@@@@@@B@@@B");
System.out.println("@B@@@B@B@B@B@52L7,.     r@@B:.:.        0B@@@@@@@@@B@BBB@");
System.out.println("@B@B@B@B@B@B@@q7i:.    :,.     :: .   :B@7@@@@@@@@UB@B@B@");
System.out.println("B@B@B@B@B@B@B@BO7;.  1@BBGMM8EGE@M:  iB5@@@@@@7.J@@@B@@@B");
System.out.println("@B@B@B@B@B@B@B@B@N7.  iur      ::   UB@@@@@@@@2B@B@B@B@B@");
System.out.println("B@B@B@B@B@B@B@B@B@B2:. .7Lriiii,   JO@@@@@@@@0B@B@B@@@@@B");
System.out.println("@B@B@B@B@B@@@B@B@@@BGr            ::@@@@@@@@8B@B@B@@@B@B@");
System.out.println("@B@B@B@B@B@@@B@B@BMkYrJ1J:,    .U@:@@@@@@@@i@@B@B@B@B@B@B");
System.out.println("B@B@@@B@B@B@B@B@B@MXr,.iYPZM@@B@@@BL@@@@@@@@v@B@B@B@B@B@@B");
System.out.println("@B@@@B@B@B@B@B@B@BOUi       ....N8@@,@@@@@@@rB@B@B@B@B@@B@");
System.out.println("@@B@B@B@@@@@B@B@BBqY:          .,7POr.@@@@@@@@B@B@B@@@@B@B");
System.out.println("@B@B@B@@@@@@@@@B@MXr,             iS7:@@@@@@@:@B@B@B@@B@B@");


    }
    
    
    public static void title(){
System.out.println(" _______  _______  _______  _______  _______  _______ ");
System.out.println("(  ____ \\(  ____ \\(  ____ \\(  ___  )(  ____ )(  ____ \\");
System.out.println("| (__    | (_____ | |      | (___) || (____)|| (__    ");
System.out.println("|  __)   (_____  )| |      |  ___  ||  _____)|  __)   ");
System.out.println("| (____/\\/\\____) || (____/\\| )   ( || )      | (____/\\");
System.out.println("(_______/\\_______)(_______/|/     \\||/       (_______/");
System.out.println(" _______  _______  _______  _______                   ");
System.out.println("(  ____ \\(  ____ )(  ___  )(       )                  ");
System.out.println("| (__    | (____)|| |   | || || || |                  ");
System.out.println("|  __)   |     __)| |   | || |(_)| |                  ");
System.out.println("| (      | (\\ (   | |   | || |   | |                  ");
System.out.println("|/       |/   \\__/(_______)|/    \\|                  ");
System.out.println("_________ _        _______  _______           _______ ");
System.out.println("\\__   __/| \\    /\\(  ___  )(  ____ )|\\     /|(  ____ \\");
System.out.println("   ) (   |  \\  / /| (   ) || (    )|| )   ( || (    \\/");
System.out.println("   | |   |   _ (  |  ___  ||     __)| |   | |(_____  )");
System.out.println("___) (___|  /  \\ \\| )   ( || ) \\ \\__| (___) |/\\____) |");
System.out.println("\\_______/|_/    \\/|/     \\||/   \\__/(_______)\\_______)");
    }
    
    
    
public static void startInfo(UserInput userinput){
              
System.out.println("In a distant, but not so unrealistic, future  ");
System.out.println("mankind has abandoned earth because it has become");
System.out.println("uninhabitable due to a nuclear war.");
System.out.println("Earth is covered in poisonous fallout and surviving ");
System.out.println("people have been evacuated from their homes and moved");
System.out.println("to star ship colonies.");
System.out.println("Space is crowded, however, and a constant war goes on");
System.out.println("between alien races. Aliens kidnap humans to work");
System.out.println("as slaves in their war factories.");    
System.out.println(" ____________________________________________");
System.out.println("|"+userinput.getMessage());
System.out.println("|_Controls_____|_Symbols________|");
System.out.println("| w = up       | P = player     |");
System.out.println("| s = down     | # = wall       |");
System.out.println("| a = left     | & _ | @ = door |");
System.out.println("| d = right    | O = use square |");
System.out.println("| g = get item | L = lift       |");
System.out.println("| u = use item | . = floor      |");
System.out.println("| t = talk     | G = guard      |");
System.out.println("|              | A = ?          |");
    }


public static void prisoner(){
                                            
System.out.println("            :8OGF1r               ");      
System.out.println("            @@@B@B@:              ");           
System.out.println("            @B@B@BBF              ");      
System.out.println("              NBB                 ");      
System.out.println("              k8@BM0ki            ");          
System.out.println("            .B@B@B@BMBO           ");            
System.out.println("            B  B@BBM@B@@Y          ");      
System.out.println("           |  7B@qOB@r7:          ");   
System.out.println("           b   @BSF@@  v          ");   
System.out.println("               B@GiB@J            ");     
System.out.println("              v@@B P@Bi           ");   
System.out.println("              B@@@7kB@B           ");      
System.out.println("              .7@q,.@B7    vZBOJ  ");      
System.out.println("               SBi  8@PvquB@B@B@B.");      
System.out.println("           .@@@B@B  qB@   @B@B@B@,");      
System.out.println("                    7OO    7FqFr  ");
System.out.println("You were caught by a guard. \n "
        + "This time you weren't able to break out "
        + "and end up a slave on an alien planet Helios. :( ");
}

public static void escape(){
System.out.println("                  .:::::i:iiiiiiii    ..       ");
System.out.println("       ...,...........::,,:::iirr. ......:,,ir   "); 
System.out.println("     vi                                     ;7 q,"); 
System.out.println("    u,    i5ZPPOBB@B@G     ii,r.:r  r.J:r,: ;v 1.@ "); 
System.out.println("   5   ,rOB@B@B@B@B@B0     SBBS.Zr::P:u7EjU,ir 5,@@@ ");
System.out.println("  F   ;F@B@BO,   .::i;vLLvr:::r.ij,.r7:.Jv7.iL.rP@@@ ");
System.out.println(" r:  .,,.       i:         :.       .  .  .  iv:iL@@@");
System.out.println(",Xr:ii:::,,,:ii:::         :i:iii:i:i:i:::::r2ir1@@@ ");
System.out.println(" Y .         ...,:         rrrr77vvvvLLJLjJuuurL0@@@ ");
System.out.println(" Y...        ...,::.......iir;rr7r7;rrv7LvYvJUvu@@@@ ");
System.out.println(" 8jvrv7v7v7v7777r7r7r7r7r7rrrrr7rriLv7ir;rirrUJkB@@@ ");
System.out.println(" 75:rir;ririri;i;i;iiiiiiiiiiiiiii:OBu::i::;rZSq@@@@ ");
System.out.println("   GS;777r7r7r77777r7r777777777r7r7iii7r7777rGZB.@ ");
System.out.println("    FZ77777v777v77777777777777777777r77777rL7SG@  ");
System.out.println("     rOXL7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v7v77v7B@B  ");
System.out.println("       L0GkF1F2F252F25151F1F1F1F251F2F1F15UPGS    ");
System.out.println("          .::::,:::::,:,:,:,:::::,:::,:::,::;     ");
System.out.println("You launched the escape pod!  :)!");
}

public static void escapeAlone(){
                                                 
                                            
System.out.println("             ######                          ");
System.out.println("           #########                         ");
System.out.println("    ##  #############                        ");
System.out.println("  ###################                        ");
System.out.println("####################                         ");
System.out.println("#################      ###                   ");
System.out.println("##############      #########                ");
System.out.println("##############################               ");
System.out.println("###############################              ");
System.out.println("#################################            ");
System.out.println("########################   ########          ");
System.out.println("########################    ########         ");
System.out.println("#######################      #########       ");
System.out.println("#######################      #########       ");
System.out.println("######################       #############   ");
System.out.println(" ###################          ############## ");
System.out.println("You escape but you'll always wonder what happened to Aino! :/");
               
}
 

public static void happyEnd(){
System.out.println("-,;;;,;,,,,,,...,...............  ..,,;,;,,####X,;------=-=-");
System.out.println(";,;;,;,,,,.,..................  ... .,,;;,,#####,--------==-");
System.out.println(";.;,,,,,,.,.......... .......  .###+ ,,,;. x###; ,--------=-");
System.out.println(";,,;,,,,........ . . . . ...   #####..,,...=###+-;,;-----==-");
System.out.println(";.;,,,,,,........              ####+  ,.;X########X,;---=-=-");
System.out.println(";,,;,,,,........             ;x#####-.  ###########x,----==-");
System.out.println("-;--;;;;;,,,,...            =####X####..#XX#######x#X-======");
System.out.println("--------;;;;,,....          +#########;=#+=#######X#x-=+=+++");
System.out.println("=-=--------;-;;,,,..    ..,.X####X####xx#;=#########+=++++++");
System.out.println("=-====-=-=------;-;;;;,;;-;,X#X#####Xx##+,x#########=+++++++");
System.out.println("+============---=--===+====-#X#######+x#x=##########++++++++");
System.out.println("--------------------++++++==##########X##+##########++++++++");
System.out.println("+=+++======-----------------=####X####+==-X#########+=++++++");
System.out.println("============------------------###xX###-===##########x++++++x");
System.out.println("+=+=+==========---------------###=x##x-===##########X+++++++");
System.out.println("+==+=+======-=----------------+##++##+-+==X#########X++++x+x");
System.out.println("=-=-=-=-=----------------------##++##+-=+==x########++++xxxx");
System.out.println("You escape together to your home ship Daedalus with Aino and\n live happily ever after. :) ");
}
    
}
